import * as pdfjsLib from '../build/pdf.min.mjs';

pdfjsLib.GlobalWorkerOptions.workerSrc = '../build/worker-wrapper.mjs';

const viewer = document.getElementById('viewer');
const hint = document.getElementById('hint');
const pageLabel = document.getElementById('page');
const source = new URLSearchParams(location.search).get('file');

const state = {
    doc: null,
    pages: [],
    scale: 1,
    current: -1,
    aspect: 1.414
};

let observer = null;

function post(type, payload) {
    const channel = window.pdfBridge;
    if (!channel) {
        return;
    }
    channel.postMessage(JSON.stringify(Object.assign({ type }, payload || {})));
}

function containerWidth() {
    return Math.max(200, viewer.clientWidth - 16);
}

function fail(message) {
    hint.classList.remove('hidden');
    hint.textContent = '打开失败：' + message;
    post('error', { message: String(message) });
}

function layoutReady() {
    return new Promise((resolve) => {
        let tries = 0;
        const timer = setInterval(() => {
            tries += 1;
            if (viewer.clientWidth >= 40 || tries >= 60) {
                clearInterval(timer);
                resolve();
            }
        }, 50);
    });
}

async function start() {
    if (!source) {
        fail('缺少 file 参数');
        return;
    }
    await layoutReady();
    try {
        state.doc = await pdfjsLib.getDocument({
            url: source,
            cMapUrl: '../cmaps/',
            cMapPacked: true,
            standardFontDataUrl: '../standard_fonts/'
        }).promise;
    } catch (error) {
        fail(error && error.message ? error.message : error);
        return;
    }
    const first = await state.doc.getPage(1);
    const viewport = first.getViewport({ scale: 1 });
    state.aspect = viewport.width / viewport.height;
    buildPages();
    post('ready', { pages: state.doc.numPages });
    observeResize();
    requestAnimationFrame(() => render(0));
}

/*
 * WebView 在插件面板里会先以 0 宽加载，再被撑到实际宽度。
 * window.resize 不一定触发，这里直接盯住容器宽度变化后重排。
 */
let lastWidth = 0;

function observeResize() {
    if (typeof ResizeObserver !== 'function') {
        return;
    }
    lastWidth = containerWidth();
    const observer = new ResizeObserver(() => {
        if (!state.doc || !state.pages.length) {
            return;
        }
        const width = containerWidth();
        if (Math.abs(width - lastWidth) < 8) {
            return;
        }
        lastWidth = width;
        resetPages();
        render(Math.max(state.current, 0));
    });
    observer.observe(viewer);
}

function buildPages() {
    const width = containerWidth();
    observer = new IntersectionObserver(onIntersect, { root: viewer, rootMargin: '800px 0px' });
    for (let index = 0; index < state.doc.numPages; index += 1) {
        const holder = document.createElement('div');
        holder.className = 'page';
        holder.dataset.index = String(index);
        holder.style.width = width + 'px';
        holder.style.aspectRatio = '1 / ' + (1 / state.aspect);
        viewer.appendChild(holder);
        const item = { holder, rendered: false, busy: false };
        state.pages.push(item);
        observer.observe(holder);
    }
}

function onIntersect(entries) {
    entries.forEach((entry) => {
        const index = Number(entry.target.dataset.index);
        if (entry.isIntersecting) {
            render(index);
            updateCurrent(index);
        }
    });
}

async function render(index) {
    const item = state.pages[index];
    if (!item || item.rendered || item.busy || !state.doc) {
        return;
    }
    item.busy = true;
    try {
        const page = await state.doc.getPage(index + 1);
        const unscaled = page.getViewport({ scale: 1 });
        const width = containerWidth() * state.scale;
        const viewport = page.getViewport({ scale: width / unscaled.width });
        const ratio = Math.min(window.devicePixelRatio || 1, 3);

        const canvas = document.createElement('canvas');
        canvas.width = Math.floor(viewport.width * ratio);
        canvas.height = Math.floor(viewport.height * ratio);
        canvas.style.width = viewport.width + 'px';
        canvas.style.height = viewport.height + 'px';

        item.holder.style.width = viewport.width + 'px';
        item.holder.style.aspectRatio = viewport.width + ' / ' + viewport.height;

        await page.render({
            canvasContext: canvas.getContext('2d'),
            viewport,
            transform: ratio === 1 ? null : [ratio, 0, 0, ratio, 0, 0]
        }).promise;

        const textLayer = document.createElement('div');
        textLayer.className = 'textLayer';
        textLayer.style.width = viewport.width + 'px';
        textLayer.style.height = viewport.height + 'px';
        textLayer.style.setProperty('--scale-factor', String(viewport.scale));

        item.holder.replaceChildren(canvas, textLayer);
        item.rendered = true;
        hint.classList.add('hidden');
        await renderText(page, textLayer, viewport);
    } catch (error) {
        console.warn('page render failed', index + 1, error);
    } finally {
        item.busy = false;
    }
}

async function renderText(page, container, viewport) {
    if (!pdfjsLib.TextLayer) {
        return;
    }
    try {
        const layer = new pdfjsLib.TextLayer({
            textContentSource: page.streamTextContent(),
            container,
            viewport
        });
        await layer.render();
    } catch (error) {
        console.warn('text layer failed', error);
    }
}

function updateCurrent(index) {
    if (state.current !== index) {
        state.current = index;
        pageLabel.textContent = (index + 1) + ' / ' + state.doc.numPages;
    }
    trim(index);
}

function trim(keepIndex) {
    state.pages.forEach((item, index) => {
        if (item.rendered && Math.abs(index - keepIndex) > 6) {
            item.rendered = false;
            item.holder.replaceChildren();
        }
    });
}

function resetPages() {
    state.pages.forEach((item) => {
        item.rendered = false;
        item.busy = false;
        item.holder.style.width = containerWidth() * state.scale + 'px';
        item.holder.replaceChildren();
    });
}

function setScale(next) {
    const value = Math.min(3, Math.max(0.5, Math.round(next * 10) / 10));
    if (value === state.scale) {
        return;
    }
    state.scale = value;
    resetPages();
    render(Math.max(state.current, 0));
}

function goTo(index) {
    const target = state.pages[Math.min(Math.max(index, 0), state.pages.length - 1)];
    if (target) {
        target.holder.scrollIntoView({ block: 'start' });
    }
}

document.getElementById('prev').addEventListener('click', () => goTo(state.current - 1));
document.getElementById('next').addEventListener('click', () => goTo(state.current + 1));
document.getElementById('zoomIn').addEventListener('click', () => setScale(state.scale + 0.25));
document.getElementById('zoomOut').addEventListener('click', () => setScale(state.scale - 0.25));
document.getElementById('fit').addEventListener('click', () => setScale(1));

let resizeTimer = 0;
window.addEventListener('resize', () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => {
        if (!state.doc) {
            return;
        }
        resetPages();
        render(Math.max(state.current, 0));
    }, 200);
});

window.pdfSave = function (bytes, name) {
    if (!bytes || !bytes.length) {
        return;
    }
    const chunk = 0x8000;
    let binary = '';
    for (let index = 0; index < bytes.length; index += chunk) {
        binary += String.fromCharCode.apply(null, bytes.subarray(index, index + chunk));
    }
    post('save', { name: name || 'document.pdf', base64: btoa(binary) });
};

start();
