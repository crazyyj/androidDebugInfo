/*
 * Chrome 119 才提供 Promise.withResolvers，而设备上的 WebView 往往更旧。
 * pdf.js 4.x 在模块顶层就会调用它，因此必须在 viewer.js 之前执行。
 */
(function () {
    if (typeof Promise.withResolvers === 'function') {
        return;
    }
    Promise.withResolvers = function () {
        var resolve;
        var reject;
        var promise = new Promise(function (res, rej) {
            resolve = res;
            reject = rej;
        });
        return { promise: promise, resolve: resolve, reject: reject };
    };
})();
